<?php
    // Check if submit button is clicked
    //by checking if $_GET["submit-data"] has value
    //      isset($variable_to_be_checked);
    // if the value of the variable $variable_to_be_checked is null
    //isset() returns false. In every other case isset() returns true.

    // if submit button is clicked  
    if (isset($_GET["submit-data"])) {

        $errors = NULL;
        $success = false;

        // validate the fullname
        if (trim($_GET["fullname"])) {
           $fn = filter_var($_GET["fullname"], FILTER_SANITIZE_STRING); 
        } else {
            $errors = "<p>Please enter your full name.</p>";
        }

        //here you want to do the same thing for your email
        if (trim($_GET["email"])) {
        //if you get here, it means there is some value
        //now you need to check if that value is a proper email (with @ symbol etc)
        //if filter_var returns true, then your email is okay
        if (filter_var($_GET["email"], FILTER_VALIDATE_EMAIL)){
            $em = $_GET["email"];
        } else {
            //remove the email from $_GET array
            $_GET["email"] = NULL;

            //create error message
            $errors .= "<p>Invalid email!</p>";
        }
        } else {
            $errors .= "<p>Please enter your email.</p>";
        }

        //here you want to do the same thing for your message
        if (filter_var($_GET["message"])){
            $me = $_GET["message"];
        } else {
            $_GET["message"] = NULL;
            $errors .="<p>Please enter your message.</p>";
        }
        // Create the feedback
        if (isset($fn) && isset($em) && isset($me)) {
            $success = true;
            $feedback = "<p>Hello {$fn}, you're now subscribe with this email: {$em}, Thank you for your message!</p><p>'{$me}'</p>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Handle Form Assignment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.css">
    <link rel="stylesheet" href="./css/style.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lora|Roboto" rel="stylesheet">
</head>
<body>
  
   <header>
      
       <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="./index.php">Contact</a></li>
                <li><a href="#">Blog</a></li>
            </ul>
       </nav> 
         
   </header>
   
   <main>
        
        <div class="container">
          <form action="index.php" method="get">
              <legend>Form Assignment</legend>
                <div class="desktop-row">
                    <div class="row">
                       
                        <div class="col-25">
                            <label for="fullname">Full Name:</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="fullname" name="fullname" placeholder="Your name.." value="<?php if (isset($success) && !$success) {echo $_GET["fullname"];}  ?>">
                        </div>
                    </div>

                    <div class="row email">
                        <div class="col-25">
                            <label for="email">Email:</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="email" name="email" placeholder="Your email.." value="<?php if (isset($success) && !$success) {echo $_GET["email"];}  ?>">
                        </div>
                    </div>
                    
                    </div>

                    <div class="row">
                        <div class="col-25">
                            <label for="message">Message:</label>
                        </div>
                        <div class="col-75">
                            <textarea id="message" name="message" placeholder="Write something.." style="height:200px" value="<?php if (isset($success) && !$success) {echo $_GET["message"];}  ?>"></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <input class="submit" type="submit" value="Submit" name="submit-data">
                    </div>
          
          </form>
        </div>
        
        <?php
        
            if (isset($feedback)) {
                echo $feedback;
            }
            if (isset($errors)) {
               echo $errors; 
            }
        
        ?>
        
   </main>
   
    <footer>
      <div class="footer-row">
           <div class="icons">
                <a href="http://www.facebook.com"><i class="fab fa-facebook-f"></i></a>
                <a href="http://www.twitter.com"><i class="fab fa-twitter"></i></a>
                <a href="http://www.instagram.com"><i class="fab fa-instagram"></i></a>
                <a href="http://www.behance.net"><i class="fab fa-behance"></i></a>
            </div>
            <div class="company">
                <p>&copy Abstract Attractions</p>
                <p>123 Artsie Fartsie Lane, Ottawa, Canada</p>
                <p>123-456-7890</p>
            </div>
        </div>
        
    </footer>
    
</body>
</html>